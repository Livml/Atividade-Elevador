# Elevador Inteligente da ETEC

Feito por **Rafaela e Lívia**

## O problema

O prédio tem 5 andares (0 a 4) e 1 elevador. Não existe uma regra definida
para decidir a ordem de atendimento das chamadas, então o desafio foi criar
e comparar estratégias diferentes.

## Estratégia escolhida: C) Atender quem gera menor deslocamento

Escolhemos a estratégia **C** porque ela busca a ordem de atendimento que
minimiza o total de andares percorridos pelo elevador (somando os trajetos
vazios até a origem da chamada e os trajetos com passageiro até o destino).
Como cada andar percorrido custa tempo (3s) e cada parada custa mais tempo
(5s de porta), reduzir deslocamentos reduz diretamente o tempo total de
atendimento — ou seja, otimizar uma métrica otimiza a outra.

Como o número de chamadas é pequeno, testamos **todas as ordens possíveis**
(força bruta, com `itertools.permutations`) e escolhemos a de menor
deslocamento total. Para um número grande de chamadas isso ficaria caro
computacionalmente, mas para o cenário da ETEC (poucos andares, poucas
chamadas por vez) é uma solução exata e simples.

## Comparação com a Estratégia A (ordem de chegada)

Usando as chamadas de exemplo `[(0,4), (2,1), (3,0), (4,2)]`:

| Estratégia | Ordem de atendimento | Tempo total | Deslocamentos |
|---|---|---|---|
| A - Ordem de chegada | (0,4) → (2,1) → (3,0) → (4,2) | 94 segundos | 18 andares |
| C - Menor deslocamento | (0,4) → (4,2) → (2,1) → (3,0) | 76 segundos | 12 andares |

## Resultado

A **Estratégia C** teve o melhor desempenho, economizando **18 segundos** e
**6 deslocamentos** em relação à ordem de chegada simples. Isso acontece
porque, ao atender a chamada (0,4), o elevador já fica parado no andar 4 —
e a próxima chamada mais eficiente a se atender é justamente (4,2), que
começa exatamente onde o elevador já está, evitando viagens vazias
desnecessárias.

## Regras consideradas na simulação

- Elevador começa no andar 0.
- Transporta apenas uma pessoa por vez.
- 3 segundos para mudar de andar.
- 5 segundos para abrir e fechar a porta (uma vez ao pegar o passageiro na
  origem, outra vez ao deixá-lo no destino).

## Como rodar

```bash
python3 elevador.py
```

O script imprime a simulação das duas estratégias e a comparação final.
