"""
Desafio de Programação - O Elevador Inteligente da ETEC
Feito por Rafaela e Lívia

Simulador de elevador para comparar estratégias de atendimento de chamadas.
"""

from itertools import permutations

# ---------------------------------------------------------
# Parâmetros fixos do prédio (dados pelo enunciado)
# ---------------------------------------------------------
TEMPO_POR_ANDAR = 3   # segundos para mudar de andar
TEMPO_PORTA = 5        # segundos para abrir e fechar a porta (cada parada)
ANDAR_INICIAL = 0


def simular(chamadas, ordem):
    """
    Simula o atendimento das chamadas na ordem informada.

    chamadas: lista original de tuplas (origem, destino)
    ordem: lista de índices indicando em que ordem as chamadas serão atendidas

    Retorna um dicionário com o detalhamento da simulação.
    """
    andar_atual = ANDAR_INICIAL
    tempo_total = 0
    deslocamentos_total = 0
    log = []

    for idx in ordem:
        origem, destino = chamadas[idx]

        # 1) Elevador se desloca (vazio) até o andar de origem da chamada
        desloc_ate_origem = abs(origem - andar_atual)
        tempo_total += desloc_ate_origem * TEMPO_POR_ANDAR
        deslocamentos_total += desloc_ate_origem
        andar_atual = origem

        # 2) Abre/fecha a porta para o passageiro embarcar
        tempo_total += TEMPO_PORTA

        # 3) Elevador se desloca (com passageiro) até o destino
        desloc_ate_destino = abs(destino - origem)
        tempo_total += desloc_ate_destino * TEMPO_POR_ANDAR
        deslocamentos_total += desloc_ate_destino
        andar_atual = destino

        # 4) Abre/fecha a porta para o passageiro desembarcar
        tempo_total += TEMPO_PORTA

        log.append((origem, destino))

    return {
        "ordem_atendimento": log,
        "tempo_total": tempo_total,
        "deslocamentos_total": deslocamentos_total,
    }


def estrategia_ordem_chegada(chamadas):
    """Estratégia A: atende as chamadas na ordem em que chegaram."""
    ordem = list(range(len(chamadas)))
    return simular(chamadas, ordem)


def estrategia_menor_deslocamento(chamadas):
    """
    Estratégia C: testa todas as ordens possíveis (força bruta) e escolhe
    a que gera o menor deslocamento total. Viável aqui porque o número de
    chamadas é pequeno (prédio de 5 andares / poucas chamadas por vez).
    """
    melhor = None
    for ordem in permutations(range(len(chamadas))):
        resultado = simular(chamadas, ordem)
        if melhor is None or resultado["deslocamentos_total"] < melhor["deslocamentos_total"]:
            melhor = resultado
    return melhor


if __name__ == "__main__":
    chamadas = [(0, 4), (2, 1), (3, 0), (4, 2)]

    print("=" * 60)
    print("ELEVADOR INTELIGENTE DA ETEC - Comparação de estratégias")
    print("Feito por Rafaela e Lívia")
    print("=" * 60)
    print(f"\nChamadas recebidas: {chamadas}\n")

    print("-> Estratégia A: Atender por ordem de chegada")
    res_a = estrategia_ordem_chegada(chamadas)
    print(f"   Ordem de atendimento: {res_a['ordem_atendimento']}")
    print(f"   Tempo total: {res_a['tempo_total']} segundos")
    print(f"   Número de deslocamentos: {res_a['deslocamentos_total']} andares\n")

    print("-> Estratégia C: Atender priorizando o menor deslocamento total")
    res_c = estrategia_menor_deslocamento(chamadas)
    print(f"   Ordem de atendimento: {res_c['ordem_atendimento']}")
    print(f"   Tempo total: {res_c['tempo_total']} segundos")
    print(f"   Número de deslocamentos: {res_c['deslocamentos_total']} andares\n")

    print("=" * 60)
    if res_c["tempo_total"] < res_a["tempo_total"]:
        economia = res_a["tempo_total"] - res_c["tempo_total"]
        print(f"RESULTADO: a Estratégia C foi melhor, economizando {economia} segundos.")
    elif res_c["tempo_total"] > res_a["tempo_total"]:
        print("RESULTADO: a Estratégia A foi melhor neste caso.")
    else:
        print("RESULTADO: as duas estratégias tiveram o mesmo desempenho.")
    print("=" * 60)
